/* package com.cc05.cc05;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Cc05Application {

	public static void main(String[] args) {
		SpringApplication.run(Cc05Application.class, args);
	}

}
 */