package com.cc05.cc05.Exceptions;

public class MyException extends Exception {

    
    public MyException(String message) {
        super(message);
    }

    
}
