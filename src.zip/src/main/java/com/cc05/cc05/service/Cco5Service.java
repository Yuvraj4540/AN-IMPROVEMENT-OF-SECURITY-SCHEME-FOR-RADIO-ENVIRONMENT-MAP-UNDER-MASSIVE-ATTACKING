package com.cc05.cc05.service;

import java.util.ArrayList;
import java.util.List;

public class Cco5Service {

    public List<String> getExtractResults(int value1,int value2){

        List<String> al=new ArrayList<String>();
        
        return al;

    }
    
}
