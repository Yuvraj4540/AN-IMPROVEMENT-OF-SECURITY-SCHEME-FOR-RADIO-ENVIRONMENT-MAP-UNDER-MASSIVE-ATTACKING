package com.ns04.ns04.Repository;

import java.lang.annotation.Native;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ns04.ns04.model.UserRequestModel;


@Repository
public interface UserRequestRepository extends JpaRepository<UserRequestModel,Integer> {

    UserRequestModel findBySenderId(int userId);

    UserRequestModel findByReceiveId(int userid);

    UserRequestModel findByFileId(int fileId);
    

    
}
