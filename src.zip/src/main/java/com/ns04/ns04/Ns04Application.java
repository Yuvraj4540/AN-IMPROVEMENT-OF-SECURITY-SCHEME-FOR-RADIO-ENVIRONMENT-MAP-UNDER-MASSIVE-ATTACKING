package com.ns04.ns04;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ns04Application {

	public static void main(String[] args) {
		SpringApplication.run(Ns04Application.class, args);
	}

}
