/* package com.ns04.ns04;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ns05ApplicationTests {

	@Test
	void contextLoads() {
	}

}
 */